import logoSrc from "@/assets/logo-lavender.png";
import { MapPin, Phone, Mail } from "lucide-react";

const FooterSection = () => (
  <footer className="border-t border-border py-12 px-4 sm:px-6 lg:px-8">
    <div className="max-w-7xl mx-auto">
      {/* Main Footer Content */}
      <div className="grid md:grid-cols-3 gap-8 mb-8">
        {/* Company Info */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-2">
            <img src={logoSrc} alt="Lavender Technologies" className="h-8 w-8 rounded-lg object-cover" />
            <span className="font-display font-bold text-sm">Lavender Technologies</span>
          </div>
          <p className="text-xs text-muted-foreground max-w-xs">
            Transforming ideas into digital reality with cutting-edge technology solutions.
          </p>
        </div>

        {/* Quick Links */}
        <div className="flex flex-col gap-4">
          <h4 className="text-sm font-semibold">Quick Links</h4>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {["Services", "About", "Portfolio", "Contact"].map((l) => (
              <a
                key={l}
                href={`#${l.toLowerCase()}`}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                {l}
              </a>
            ))}
          </div>
        </div>

        {/* Contact Info */}
        <div className="flex flex-col gap-4">
          <h4 className="text-sm font-semibold">Contact Us</h4>
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <MapPin size={14} className="text-primary mt-0.5 shrink-0" />
              <span className="text-xs text-muted-foreground">
                No. 89, Wabadamulla,<br />
                Kaleliya - Medagampitiya Rd,<br />
                Veyangoda
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Phone size={14} className="text-primary shrink-0" />
              <a href="tel:0789637066" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                078 963 7066
              </a>
            </div>
            <div className="flex items-center gap-2">
              <Mail size={14} className="text-primary shrink-0" />
              <a href="mailto:hellolavendertechnologies@gmail.com" className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                hellolavendertechnologies@gmail.com
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-border pt-6">
        <p className="text-xs text-muted-foreground text-center">
          © 2026 Lavender Technologies. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

export default FooterSection;
