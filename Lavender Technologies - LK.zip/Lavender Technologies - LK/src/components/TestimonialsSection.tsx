import { motion } from "framer-motion";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Chen",
    role: "CTO, FinVerse",
    text: "Lavender Technologies transformed our legacy systems into a modern, scalable platform. Their expertise in cloud architecture is unmatched.",
  },
  {
    name: "Marcus Rivera",
    role: "CEO, HealthBridge",
    text: "The mobile app they built exceeded all expectations. Seamless UX, robust security, and delivered ahead of schedule.",
  },
  {
    name: "Elena Kowalski",
    role: "VP Engineering, DataSync",
    text: "Their AI solutions cut our processing time by 70%. A truly innovative team that understands enterprise needs.",
  },
];

const TestimonialsSection = () => (
  <section id="testimonials" className="section-padding relative">
    <div className="absolute inset-0 opacity-5">
      <div
        className="h-full w-full"
        style={{
          backgroundImage: `radial-gradient(circle at 80% 50%, hsl(var(--accent)) 0%, transparent 50%)`,
        }}
      />
    </div>
    <div className="max-w-7xl mx-auto relative z-10">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <span className="text-xs font-semibold tracking-widest uppercase text-primary mb-3 block">Testimonials</span>
        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">What Clients Say</h2>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6">
        {testimonials.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.15 }}
            className="glass-card p-8 rounded-2xl"
          >
            <div className="flex gap-1 mb-5">
              {[...Array(5)].map((_, j) => (
                <Star key={j} size={14} className="fill-primary text-primary" />
              ))}
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6 italic">"{t.text}"</p>
            <div>
              <p className="font-display font-semibold text-sm">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.role}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default TestimonialsSection;
