import { motion } from "framer-motion";
import { Globe, Smartphone, Cloud, Bot } from "lucide-react";

const services = [
  {
    icon: Globe,
    title: "Web Development",
    desc: "Scalable, high-performance web applications built with modern frameworks and cutting-edge architecture.",
    accent: "primary",
  },
  {
    icon: Smartphone,
    title: "Mobile App Development",
    desc: "Native and cross-platform mobile experiences that users love, from concept to deployment.",
    accent: "accent",
  },
  {
    icon: Cloud,
    title: "Cloud Solutions",
    desc: "Enterprise-grade cloud infrastructure, migration, and optimization for maximum efficiency.",
    accent: "neon-green",
  },
  {
    icon: Bot,
    title: "AI & Automation",
    desc: "Intelligent automation and machine learning solutions that drive business transformation.",
    accent: "neon-blue",
  },
];

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15, ease: "easeOut" as const },
  }),
};

const ServicesSection = () => (
  <section id="services" className="section-padding">
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <span className="text-xs font-semibold tracking-widest uppercase text-primary mb-3 block">What We Do</span>
        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">Our Services</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">End-to-end technology solutions tailored to accelerate your digital transformation.</p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((s, i) => (
          <motion.div
            key={s.title}
            custom={i}
            variants={cardVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            whileHover={{ y: -8, transition: { duration: 0.25 } }}
            className="glass-card p-6 lg:p-8 rounded-2xl group cursor-default"
          >
            <div className={`w-12 h-12 rounded-xl bg-${s.accent}/10 flex items-center justify-center mb-5`}>
              <s.icon size={24} className={`text-${s.accent}`} />
            </div>
            <h3 className="font-display font-semibold text-lg mb-3">{s.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
