import { motion } from "framer-motion";
import { ExternalLink } from "lucide-react";

const projects = [
  {
    title: "FinFlow Dashboard",
    category: "Web Application",
    desc: "Real-time financial analytics platform with AI-driven insights and portfolio management.",
    gradient: "from-primary to-accent",
  },
  {
    title: "MedConnect Mobile",
    category: "Mobile App",
    desc: "HIPAA-compliant telemedicine app connecting patients with healthcare providers globally.",
    gradient: "from-accent to-neon-green",
  },
  {
    title: "CloudScale Platform",
    category: "Cloud Infrastructure",
    desc: "Auto-scaling microservices architecture serving 10M+ daily active users.",
    gradient: "from-neon-purple to-primary",
  },
  {
    title: "AutoPilot AI",
    category: "AI & Automation",
    desc: "Intelligent workflow automation suite reducing operational costs by 60% for enterprises.",
    gradient: "from-neon-green to-accent",
  },
];

const PortfolioSection = () => (
  <section id="portfolio" className="section-padding">
    <div className="max-w-7xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="text-center mb-16"
      >
        <span className="text-xs font-semibold tracking-widest uppercase text-primary mb-3 block">Our Work</span>
        <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-4">Featured Projects</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">Innovative solutions that have transformed industries.</p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            whileHover={{ y: -6 }}
            className="glass-card rounded-2xl overflow-hidden group cursor-pointer"
          >
            <div className={`h-48 bg-gradient-to-br ${p.gradient} opacity-20 group-hover:opacity-30 transition-opacity relative`}>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-14 rounded-lg border border-foreground/10 bg-card/50 backdrop-blur" />
              </div>
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-primary">{p.category}</span>
                <ExternalLink size={14} className="text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
              <h3 className="font-display font-semibold text-xl mb-2">{p.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default PortfolioSection;
