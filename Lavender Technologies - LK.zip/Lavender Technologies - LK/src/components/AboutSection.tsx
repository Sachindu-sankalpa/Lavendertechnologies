import { motion, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Shield, Zap, Users, Award } from "lucide-react";

const stats = [
  { value: 150, suffix: "+", label: "Projects Delivered", icon: Award },
  { value: 50, suffix: "+", label: "Team Members", icon: Users },
  { value: 99, suffix: "%", label: "Client Satisfaction", icon: Shield },
  { value: 12, suffix: "+", label: "Years Experience", icon: Zap },
];

const Counter = ({ value, suffix }: { value: number; suffix: string }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const duration = 2000;
    const step = (ts: number) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      setCount(Math.floor(progress * value));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [inView, value]);

  return (
    <span ref={ref} className="font-display text-3xl sm:text-4xl font-bold gradient-text">
      {count}{suffix}
    </span>
  );
};

const AboutSection = () => (
  <section id="about" className="section-padding relative">
    <div className="absolute inset-0 opacity-5">
      <div
        className="h-full w-full"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, hsl(var(--primary)) 0%, transparent 60%)`,
        }}
      />
    </div>
    <div className="max-w-7xl mx-auto relative z-10">
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <span className="text-xs font-semibold tracking-widest uppercase text-primary mb-3 block">About Us</span>
          <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold mb-6">
            Engineering Excellence<br />Since 2014
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-4">
            Lavender Technologies is a global software company dedicated to building innovative, scalable, and secure digital solutions for enterprises worldwide.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8">
            Our team of world-class engineers, designers, and strategists partner with businesses to transform ambitious ideas into market-defining products.
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-primary/10 hover:bg-primary/20 text-primary font-medium px-6 py-3 rounded-xl transition-colors"
          >
            Learn More About Us
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="grid grid-cols-2 gap-4"
        >
          {stats.map((s) => (
            <div key={s.label} className="glass-card p-6 rounded-2xl text-center">
              <s.icon size={20} className="text-primary mx-auto mb-3" />
              <Counter value={s.value} suffix={s.suffix} />
              <p className="text-xs text-muted-foreground mt-2">{s.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  </section>
);

export default AboutSection;
